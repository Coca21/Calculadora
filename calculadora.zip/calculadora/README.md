# Calculadora de salário em TypeScript
