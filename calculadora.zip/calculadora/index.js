var Funcionario = /** @class */ (function () {
    function Funcionario() {
        this.Dedutivel = 0;
        this.funcionario = {};
    }
    Funcionario.prototype.calcularHorasExtras = function (salarioBruto, horaExtra) {
        this.funcionario.NumeroHorasExtra = 200;
        this.funcionario.valorHora = salarioBruto / this.funcionario.NumeroHorasExtra;
        this.funcionario.valorHoraExtra = this.funcionario.valorHora * (!horaExtra ? this.funcionario.horasExtra = 0 : this.funcionario.horasExtra = horaExtra);
        this.funcionario.salarioExtra = salarioBruto + this.funcionario.valorHoraExtra;
        return this.funcionario.salarioExtra;
    };
    Funcionario.prototype.calculoINSS = function (salarioBruto) {
    
    var salarioMinimo = 1212.00
    var salarioMedio = 2427.36
    var salarioAlto = 3641.03
    var salarioMaximo = 7087.22
    
        if (salarioBruto <= salarioMinimo) {
            this.funcionario.faixaDesconto = 0.075;
            this.funcionario.Desconto = salarioBruto * this.funcionario.faixaDesconto;
        }
        if (salarioBruto >= salarioMinimo && salarioBruto <= salarioMedio) {
            this.funcionario.faixaDesconto = 0.09;
            this.funcionario.Desconto = salarioMinimo * 0.075;
            this.funcionario.Desconto = this.funcionario.Desconto + ((salarioBruto - salarioMinimo) * this.funcionario.faixaDesconto);
        }
        if (salarioBruto >= salarioMedio && salarioBruto <= salarioAlto) {
            this.funcionario.faixaDesconto = 0.12;
            this.funcionario.Desconto = salarioMinimo * 0.075;
            this.funcionario.Desconto = this.funcionario.Desconto + (salarioMedio - salarioMinimo) * 0.09;
            this.funcionario.Desconto = this.funcionario.Desconto + (salarioBruto - salarioMedio) * this.funcionario.faixaDesconto;
        }
        if (salarioBruto >= salarioAlto && salarioBruto <= salarioMaximo) {
            this.funcionario.faixaDesconto = 0.14;
            this.funcionario.Desconto = salarioMinimo * 0.075;
            this.funcionario.Desconto = this.funcionario.Desconto + (salarioMedio - salarioMinimo) * 0.09;
            this.funcionario.Desconto = this.funcionario.Desconto + (salarioAlto - salarioMedio) * 0.12;
            this.funcionario.Desconto = this.funcionario.Desconto + (salarioBruto - salarioAlto) * this.funcionario.faixaDesconto;
        }
        if (salarioBruto >= salarioMaximo) {
            this.funcionario.faixaDesconto = 0.014;
            this.funcionario.Desconto = 992.23;
        }
        return this.funcionario.Desconto;
    };
    Funcionario.prototype.calculoIr = function (salarioBruto) {
    
    var salarioMinimo = 1903.98
    var salarioMedio = 2826.65
    var salarioAlto = 3751.05
    var salarioMaximo = 4664.68
    
        if (salarioBruto <= salarioMinimo) {
            this.funcionario.Ir = 0;
            this.funcionario.descontoIr = 0;
        }
        if (salarioBruto >= salarioMinimo && salarioBruto <= salarioMedio) {
            this.funcionario.Ir = 0.075;
            this.Dedutivel = 142, 80;
            this.funcionario.descontoIr = (salarioBruto * this.funcionario.Ir) - this.Dedutivel;
        }
        if (salarioBruto >= salarioMedio && salarioBruto <= salarioAlto) {
            this.funcionario.Ir = 0.015;
            this.Dedutivel = 354, 80;
            this.funcionario.descontoIr = (salarioBruto * this.funcionario.Ir) - this.Dedutivel;
        }
        if (salarioBruto >= salarioAlto && salarioBruto <= salarioMaximo) {
            this.funcionario.Ir = 0.225;
            this.Dedutivel = 636.13;
            this.funcionario.descontoIr = (salarioBruto * this.funcionario.Ir) - this.Dedutivel;
        }
        if (salarioBruto >= salarioMaximo) {
            this.funcionario.Ir = 0.275;
            this.Dedutivel = 869.36;
            this.funcionario.descontoIr = (salarioBruto * this.funcionario.Ir) - this.Dedutivel;
        }
        return this.funcionario.descontoIr;
    };
    Funcionario.prototype.SalarioLiquido = function (salarioHoraExtra, Desconto, descontoIr) {
        this.funcionario.salarioLiquido = salarioHoraExtra - descontoIr - Desconto;
    };
    Funcionario.prototype.setNome = function (novoNome) {
        this.funcionario.nome = novoNome;
    };
    return Funcionario;
}());
var func = new Funcionario();
{
}
function principal(nome, salario, horasExtras) {
    func.calcularHorasExtras(salario, horasExtras);
    func.calculoINSS(salario);
    func.calculoIr(func.funcionario.salarioExtra - func.funcionario.Desconto);
    func.SalarioLiquido(func.funcionario.salarioExtra, func.funcionario.Desconto, func.funcionario.descontoIr);
    //
    console.log("Nome: " + nome);
    console.log("Salário Bruto: " + salario);
    console.log("Horas Extras: " + horasExtras);
    console.log("Salario + Hora Extra: " + func.funcionario.salarioExtra);
    console.log("Faixa INSS: " + (func.funcionario.faixaDesconto * 100).toFixed(2));
    console.log("Desconto INSS: " + func.funcionario.Desconto);
    console.log("Salario Base IR: " + (func.funcionario.salarioExtra - func.funcionario.Desconto));
    console.log("Faixa IR: " + (func.funcionario.Ir * 100).toFixed(2));
    console.log("Desconto IR:" + func.funcionario.descontoIr);
    console.log("Salário Líquido: " + func.funcionario.salarioLiquido);
}
principal(process.argv[2], Number(process.argv[3]), Number(process.argv[4]));
